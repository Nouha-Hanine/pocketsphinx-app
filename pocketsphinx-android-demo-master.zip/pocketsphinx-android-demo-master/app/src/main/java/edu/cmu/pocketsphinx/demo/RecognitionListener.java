package edu.cmu.pocketsphinx.demo;

import edu.cmu.pocketsphinx.Hypothesis;

public interface RecognitionListener {
    //void onResult(Hypothesis hypothesis);
}